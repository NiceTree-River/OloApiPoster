param(
    [string]$PackageRoot = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'
$appName = 'OLO API Desktop Tool'
$installPath = Join-Path $env:LOCALAPPDATA 'Programs\OloApiDesktopTool'
$appSource = Join-Path $PackageRoot 'app'

if (-not (Test-Path (Join-Path $appSource 'OloApiDesktopTool.exe'))) {
    throw "The application files were not found in '$appSource'."
}

New-Item -ItemType Directory -Force -Path $installPath | Out-Null
Copy-Item -Path (Join-Path $appSource '*') -Destination $installPath -Recurse -Force

$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$shortcutPath = Join-Path $startMenu "$appName.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = Join-Path $installPath 'OloApiDesktopTool.exe'
$shortcut.WorkingDirectory = $installPath
$shortcut.Description = $appName
$shortcut.Save()

$uninstallScript = Join-Path $installPath 'Uninstall.ps1'
@"
`$ErrorActionPreference = 'SilentlyContinue'
Remove-Item -LiteralPath '$shortcutPath' -Force
Remove-Item -LiteralPath '$installPath' -Recurse -Force
"@ | Set-Content -Path $uninstallScript -Encoding UTF8

Write-Host "$appName was installed to $installPath"
Write-Host "A Start Menu shortcut was created."
